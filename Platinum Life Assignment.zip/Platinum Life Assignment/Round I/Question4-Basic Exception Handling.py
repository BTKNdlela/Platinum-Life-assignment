def main():
    qty = None
    cost = None
def fetch_quantity():
    """
    Returns a number, any number
    """
    try:
        ...
    except:
        print("")




    ...
    return ...
def fetch_cost():
    """
    Returns a number, any number
    """
    try:
        ...
    finally:
        ...
    return ...
def compute_cost_per_quantity():
    qty = fetch_quantity()
    cost = fetch_cost()
    try:
        cost_per_quantity = cost/qty
    except:
        print("")
    return cost_per_quantity
    cost_per_quantity = compute_cost_per_quantity()
    a = 1 + 2 + cost_per_quantity
    b = 4 + 5
    print(a+b)
