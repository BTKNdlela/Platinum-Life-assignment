for i in range(1, 11):
    if i==6:
    #your code here#
        continue
    else:
        print(i, end=',')