class TestMath:
    x = 10
    y = 10

    def test_add(x,y):
        return x + y
    def test_subtract(x,y):
        return x - y
    def test_milutiply(x,y):
        return x * y