def is_date_format_correct(date:str)->bool:
    """
    This function takes in a date in string format
    and returns true if the date matches the format
    YYYY-MM-DD and false if it doesn't
    """
    #your code here#
    is_correct = True
    maxLength = 10
    split = "-"
    if len(date) > maxLength :
        is_correct = False
    if date[-3] != split and date[-6] != split :#
        is_correct = False

    return is_correct

print(is_date_format_correct("2012/08/26"))





