import datetime


def compute_prev_date(dates_list:list):
    """
    """
    previousDates = []
    monthAbbreviation = {"01": "Jan", "02": "Feb", "03": "Mar", "04": "Apr", "05": "May", "06": "Jun", "07": "Jul",
                         "08": "Aug", "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dec", }
    for date in dates_list:
        previousDay = ""
        stringBuilderForMonthAbbreviation = "0"
        abbreviatedMonth = "Jan"
        removedSplitDate = date.split("-")
        year = int(removedSplitDate[0])
        month = int(removedSplitDate[1])
        day = int(removedSplitDate[2])
        previousDate = datetime.datetime(year, month, day).date() - datetime.timedelta(days=1)
        if (previousDate.month < 10):
            stringBuilderForMonthAbbreviation += str(previousDate.month)
            abbreviatedMonth = monthAbbreviation.get(stringBuilderForMonthAbbreviation)
        else:
            abbreviatedMonth = monthAbbreviation.get(str(previousDate.month))
        previousDay = previousDate.strftime("%d") + " " + abbreviatedMonth + " " + previousDate.strftime("%Y")
        previousDates.append(previousDay)
    return [ previousDates ]


#Output : 20 Jan 1999#
dates = ['1999-01-21', '2022-12-30', '2099-12-21']

print(compute_prev_date(dates))