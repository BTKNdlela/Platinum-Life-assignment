import pandas as pd #dependency
import numpy as np #dependency

df_teacher = pd.DataFrame({
    "name": ["Pep Guardiola", "Jurgen Klopp", "Mikel Arteta", "Zinadine Zidane"],
    "married": [True, True, False, True],
    "school": ["Manchester High School", "Liverpool High School", "Arsenal High", np.nan]
    })

df_student = pd.DataFrame({
    "teacher": ["Mikel Arteta", "Mikel Arteta", "Pep Guardiola", "Jurgen Klopp", "Jurgen Klopp", "Jurgen Klopp", "Pep Guardiola","Pep Guardiola","Mikel Arteta"],
    "name": ["Bukayo Saka", "Gabriel Martinelli", "Jack Grealish", "Roberto Firmino","Andrew Robertson", "Darwin Nunez", "Ederson Moraes", "Manuel Akanji", "Thomas Partey"],
    "age": [21, 21, 27, 31, 28, 23, 29, 27, 29],
    "height": ['2.1m','2.1m', '2.1m', '2.1m', '2.1m', '2.1m', '2.1m', '2.1m', '2.1m']
    })

df_school = pd.merge(df_teacher,df_student,how = 'inner',left_on = 'name', right_on = 'teacher')
numberOfColumns = len(df_school.columns)
grouped = df_student.groupby(['teacher'])['name'].apply(list)

finalStudents =({
    "student":"Roberto Firmino",
    "age":"31.0",
    "height":"2.1m",
    "weight":"73kg"
})
finalOutCome = ([{
    "teacher": "Jurgen Klopp",
    "school": "Liverpool High School",
    "married": "true",
    "Students": [
        finalStudents
    ]
}])
"""print(grouped)
print(grouped[1][2])"""

for row in range(len(grouped.index)):
    print(grouped.index[row])
    for col in range(len(grouped[row])):
        print(grouped[row][col])

"""finalOutcome = ""
for row in range(len(df_school)):
    if (df_school['teacher'][row] == df_school['teacher'][row+1]):
       print("YESSS")
    #finalOutcome += "[{'teacher':'"+str(df_school['teacher'][row])+"','school':'"+str(df_school['school'][row])+"','married':'"+str(df_school['married'][row])+"' }]"
    #for column in range(numberOfColumns):#

        #print(df_school.iloc[row,column])#

print(finalOutcome)"""

